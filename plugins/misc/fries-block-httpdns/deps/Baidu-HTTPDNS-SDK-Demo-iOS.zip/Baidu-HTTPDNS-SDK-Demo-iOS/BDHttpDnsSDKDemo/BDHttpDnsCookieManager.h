//
//  BDHttpDnsCookieManager.h
//  BDHttpDnsSDKDemo
//
//  Created by Csy on 2018/11/7.
//  Copyright © 2018 baidu. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BDHttpDnsCookieManager : NSObject

+ (instancetype)sharedInstance;

/**
 解析响应头中的cookie，并且存储到NSHTTPCookieStorage
 
 @param headerFields 响应头
 @param URL 关联的URL
 @return 解析出的cookie数组
 */
- (NSArray<NSHTTPCookie *> *)parseHeaderFields:(NSDictionary *)headerFields forURL:(NSURL *)URL;

/**
 从NSHTTPCookieStorage，获取URL对应的cookie
 
 @param URL 关联的URL
 @return URL对应的cookie
 */
- (NSString *)cookieForURL:(NSURL *)URL;

/**
 从NSHTTPCookieStorage，删除URL对应的cookie
 
 @param URL 关联的URL
 @return 删除cookie的数量
 */
- (NSInteger)deleteCookieForURL:(NSURL *)URL;

@end

NS_ASSUME_NONNULL_END
