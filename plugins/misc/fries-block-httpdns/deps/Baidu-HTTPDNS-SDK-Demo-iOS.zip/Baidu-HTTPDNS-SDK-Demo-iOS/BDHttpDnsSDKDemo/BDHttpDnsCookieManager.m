//
//  BDHttpDnsCookieManager.m
//  BDHttpDnsSDKDemo
//
//  Created by Csy on 2018/11/7.
//  Copyright © 2018 baidu. All rights reserved.
//

#import "BDHttpDnsCookieManager.h"

@implementation BDHttpDnsCookieManager

+ (instancetype)sharedInstance {
    static BDHttpDnsCookieManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!instance) {
            instance = [[self alloc] init];
        }
    });
    return instance;
}

- (NSArray<NSHTTPCookie *> *)parseHeaderFields:(NSDictionary *)headerFields forURL:(NSURL *)URL {
    NSArray *cookieList = [NSHTTPCookie cookiesWithResponseHeaderFields:headerFields forURL:URL];
    if (cookieList == nil) {
        return nil;
    }
    
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in cookieList) {
        if ([self p_checkCookie:cookie URL:URL]) {
            [cookieStorage setCookie:cookie];
        }
    }
    return cookieList;
}

- (NSString *)cookieForURL:(NSURL *)URL {
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSMutableArray *cookieList = [NSMutableArray array];
    for (NSHTTPCookie *cookie in [cookieStorage cookies]) {
        if (![self p_checkCookie:cookie URL:URL]) {
            continue;
        }
        [cookieList addObject:cookie];
    }
    
    if (cookieList.count > 0) {
        NSDictionary *cookieDic = [NSHTTPCookie requestHeaderFieldsWithCookies:cookieList];
        if ([cookieDic objectForKey:@"Cookie"]) {
            return cookieDic[@"Cookie"];
        }
    }
    return nil;
}

- (NSInteger)deleteCookieForURL:(NSURL *)URL {
    int delCount = 0;
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in [cookieStorage cookies]) {
        if ([self p_checkCookie:cookie URL:URL]) {
            [cookieStorage deleteCookie:cookie];
            delCount++;
        }
    }
    return delCount;
}

- (BOOL)p_checkCookie:(NSHTTPCookie *)cookie URL:(NSURL *)URL {
    if (cookie.domain.length <= 0 || URL.host.length <= 0) {
        return NO;
    }
    if ([URL.host containsString:cookie.domain]) {
        return YES;
    }
    return NO;
}

@end
