package com.baidu.httpdns.httpdnssdkdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import com.baidu.bdhttpdns.BDHttpDns;

import java.util.ArrayList;
import java.util.Arrays;


public class MainActivity extends Activity implements View.OnClickListener {

    // 测试账户ID：bdy_10000000，测试secret：e7452f1b4c
    private static final String accountID = "bdy_10000000";
    private static final String secret = "e7452f1b4c";
    private BDHttpDns httpDns;
    private Button webviewScene;
    private Button urlConnectionScene;
    private Button okHttpScene;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        // UI控件初始化

        webviewScene = (Button) findViewById(R.id.webView);
        urlConnectionScene = (Button) findViewById(R.id.urlConnection);
        okHttpScene = (Button) findViewById(R.id.okhttp);

        // 预加载域名初始化
        ArrayList<String> hosts = new ArrayList<>(
                Arrays.asList("www.baidu.com", "cloud.baidu.com"));
        // httpDns服务实例初始化
        httpDns = BDHttpDns.getService(getApplicationContext());
        // 设置是否打开日志开关，默认关闭日志输出
        httpDns.setLogEnable(true);
        // 租户account和secret初始化
        try {
            httpDns.setAccountID(accountID);
            httpDns.setSecret(secret);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        // 设置是否通过HTTPS协议解析域名，默认为https请求
        httpDns.setHttpsRequestEnable(true);
        // 设置网络变化是否清除缓存，默认清除缓存
        // 设置网络变化是否对缓存中的所有域名进行预取，默认预取
        httpDns.setNetworkSwitchPolicy(true, true);
        // 设置域名缓存策略，默认为容忍型
        httpDns.setCachePolicy(BDHttpDns.CachePolicy.POLICY_TOLERANT);
        // 开始解析预加载的域名列表
        httpDns.setPreResolveHosts(hosts);

        webviewScene.setOnClickListener(this);
        urlConnectionScene.setOnClickListener(this);
        okHttpScene.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.webView:
                Intent webViewIntent = new Intent(this, WebviewActivity.class);
                startActivity(webViewIntent);
                break;
            case R.id.okhttp:
                Intent okHttpIntent = new Intent(this, OkHttpActivity.class);
                startActivity(okHttpIntent);
                break;
            case R.id.urlConnection:
                Intent urlConnectionIntent = new Intent(this, HttpURLConnectionActivity.class);
                startActivity(urlConnectionIntent);
                break;
            default:
                break;

        }
    }

}
