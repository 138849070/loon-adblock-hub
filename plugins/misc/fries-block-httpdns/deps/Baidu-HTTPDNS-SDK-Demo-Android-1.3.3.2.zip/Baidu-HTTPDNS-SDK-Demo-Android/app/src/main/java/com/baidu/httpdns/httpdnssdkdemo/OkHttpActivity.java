package com.baidu.httpdns.httpdnssdkdemo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.baidu.bdhttpdns.BDHttpDns;
import com.baidu.bdhttpdns.BDHttpDnsResult;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Dns;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class OkHttpActivity extends Activity implements View.OnClickListener {
    private static final String TAG = "BDHttpDnsSdkDemo";
    private BDHttpDns httpDns;
    private Button resolve;
    private Button clear;
    private EditText urlText;
    private static TextView responseText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.demo_activity_okhttp);

        // UI控件初始化
        resolve = (Button) findViewById(R.id.resolve);
        resolve.setOnClickListener(this);
        clear = (Button) findViewById(R.id.clear);
        clear.setOnClickListener(this);
        urlText = (EditText) findViewById(R.id.url);
        responseText = (TextView) findViewById(R.id.response);
        responseText.setMovementMethod(new ScrollingMovementMethod());
        // httpDns服务实例初始化
        httpDns = BDHttpDns.getService(getApplicationContext());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.resolve:
                okhttpDnsRequest();
                break;
            case R.id.clear:
                // 清除responseText的输出信息
                responseText.setText("");
                break;
            default:
                break;
        }
    }

    public static class OkHttpDns implements Dns {
        private static OkHttpDns instance = null;
        private BDHttpDns httpDns;
        
        private OkHttpDns(Context context) {
            this.httpDns = BDHttpDns.getService(context);;
        }

        public static OkHttpDns getInstance(Context context) {
            if(instance == null) {
                instance = new OkHttpDns(context);
            }
            return instance;
        }

        @Override
        public List<InetAddress> lookup(final String hostname) throws UnknownHostException {
            // 通过同步解析接口获取ip
            final BDHttpDnsResult httpDnsResult = httpDns.syncResolve(hostname, false);
            Log.v(TAG, "HttpDns resolve type: " + httpDnsResult.getResolveType());
            // 优先使用ipv6结果，对于ipv6结果，需要在ip前后增加[]字符
            // 若不存在ipv6结果，则使用ipv4结果
            ArrayList<String> ipv6List = httpDnsResult.getIpv6List();
            ArrayList<String> ipv4List = httpDnsResult.getIpv4List();
            String ip = null;
            if (ipv6List != null && !ipv6List.isEmpty()) {
                ip = "[" + ipv6List.get(0) + "]";
            } else if (ipv4List != null && !ipv4List.isEmpty()) {
                ip = ipv4List.get(0);
            } else {
                Log.v(TAG, "Get empty iplist from httpdns, use origin url");
            }

            if(ip != null) {
                final String finalIp = ip;
                responseText.post(new Runnable() {
                    @Override
                    public void run() {
                        responseText.append("Get ip:" + finalIp + " for host:"
                                + hostname + " from " + httpDnsResult.getResolveType().toString()
                                + " successfully!\n");
                    }
                });
                //如果ip不为null，直接使用该ip进行网络请求
                List<InetAddress> inetAddresses = Arrays.asList(InetAddress.getAllByName(ip));
                Log.d(TAG, "inetAddresses:" + inetAddresses);
                return inetAddresses;
            }
            //如果返回null，走系统DNS服务解析域名
            return Dns.SYSTEM.lookup(hostname);
        }
    }

    private void okhttpDnsRequest() {
        OkHttpClient client = new OkHttpClient.Builder()
                .dns(OkHttpDns.getInstance(getApplicationContext()))
                .build();
        Request request = new Request.Builder()
                .url(urlText.getText().toString())
                .build();
        Response response = null;
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(final Call call, final IOException e) {
                responseText.post(new Runnable() {
                    @Override
                    public void run() {
                        responseText.append("Request failed. Host: " + call.request().url().host() +  ". error:" + e);
                    }
                });

            }
            @Override
            public void onResponse(final Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                }
                DataInputStream dis = new DataInputStream(response.body().byteStream());
                int len;
                byte[] buff = new byte[4096];
                StringBuilder result = new StringBuilder();
                while ((len = dis.read(buff)) != -1) {
                    result.append(new String(buff, 0, len));
                }
                responseText.post(new Runnable() {
                    @Override
                    public void run() {
                        responseText.append("Get response from " + call.request().url().host()
                                + "\nPlease check response detail from BDHttpDns log\n");
                    }
                });

                Log.d(TAG, "Response: " + result.toString());
            }
        });
    }
}




