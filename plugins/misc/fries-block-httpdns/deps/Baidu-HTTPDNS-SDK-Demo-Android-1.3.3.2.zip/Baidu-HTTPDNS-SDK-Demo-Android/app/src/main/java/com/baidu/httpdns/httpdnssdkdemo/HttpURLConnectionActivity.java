package com.baidu.httpdns.httpdnssdkdemo;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.baidu.bdhttpdns.BDHttpDns;
import com.baidu.bdhttpdns.BDHttpDnsResult;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.RejectedExecutionException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class HttpURLConnectionActivity extends Activity {

    private static final String TAG = "BDHttpDnsSdkDemo";
    private BDHttpDns httpDns;
    private Button urlConnAsync;
    private Button urlConnSyncNoBlock;
    private Button urlConnSyncBlock;
    private Button clear;
    private EditText urlText;
    private static TextView responseText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.demo_activity_urlconnetion);

        // UI控件初始化
        urlConnAsync = (Button) findViewById(R.id.async);
        urlConnSyncNoBlock = (Button) findViewById(R.id.syncNoBlock);
        urlConnSyncBlock = (Button) findViewById(R.id.syncBlock);
        clear = (Button) findViewById(R.id.clear);
        urlText = (EditText) findViewById(R.id.url);
        responseText = (TextView) findViewById(R.id.response);
        responseText.setMovementMethod(new ScrollingMovementMethod());

        // 预加载域名对应tag初始化
        String tag = "abc";
        // httpDns服务实例初始化
        httpDns = BDHttpDns.getService(getApplicationContext());

        // 清除responseText的输出信息
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                responseText.setText("");
            }
        });

        // 同步阻塞接口测试HttpDns服务解析结果，用户可指定https和http类型域名验证解析的IP地址可用
        urlConnSyncBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // 设置原始url，获取host
                        String requestUrl = urlText.getText().toString();
                        String host = "";
                        try {
                            URL url = new URL(requestUrl);
                            host = url.getHost();
                            if (host == null || host.isEmpty()) {
                                Log.v(TAG, "Err: get null host from originUrlStr " + requestUrl);
                                return;
                            }
                            // 读取http dns同步阻塞解析结果，httpDnsResult存储域名解析结果
                            final BDHttpDnsResult httpDnsResult = httpDns.syncResolve(host, false);
                            Log.v(TAG, "HttpDns resolve type: " + httpDnsResult.getResolveType());
                            // 优先使用ipv6结果，对于ipv6结果，需要在ip前后增加[]字符
                            // 若不存在ipv6结果，则使用ipv4结果
                            ArrayList<String> ipv6List = httpDnsResult.getIpv6List();
                            ArrayList<String> ipv4List = httpDnsResult.getIpv4List();
                            String ip = null;
                            if (ipv6List != null && !ipv6List.isEmpty()) {
                                ip = "[" + ipv6List.get(0) + "]";
                            } else if (ipv4List != null && !ipv4List.isEmpty()) {
                                ip = ipv4List.get(0);
                            } else {
                                Log.v(TAG, "Get empty iplist from httpdns, use origin url");
                            }

                            if (ip != null) {
                                // http dns解析成功，替换url
                                requestUrl = requestUrl.replaceFirst(host, ip);
                                Log.v(TAG, "Use http dns ip(" + ip
                                        + ") for host(" + host + ") requestUrl " + requestUrl);
                                final String finalIp = ip;
                                final String finalHost = host;
                                responseText.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        responseText.append("Get ip:" + finalIp + " for host:"
                                                + finalHost + " from " + httpDnsResult.getResolveType().toString()
                                                + " successfully!\n");
                                    }
                                });
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                        // 发起请求，打印http status code
                        new AsyncHttpRequest().execute(requestUrl, host);
                    }
                }).start();
            }
        });

        // 同步非阻塞接口测试HttpDns服务解析结果，用户可指定https和http类型域名验证解析的IP地址可用
        urlConnSyncNoBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 设置原始url，获取host
                String requestUrl = urlText.getText().toString();
                String host = "";
                try {
                    URL url = new URL(requestUrl);
                    host = url.getHost();
                    if (host == null || host.isEmpty()) {
                        Log.v(TAG, "Err: get null host from originUrlStr " + requestUrl);
                        return;
                    }
                    // 读取http dns同步非阻塞解析结果，httpDnsResult存储域名解析结果
                    final BDHttpDnsResult httpDnsResult = httpDns.syncResolve(host, true);
                    Log.v(TAG, "HttpDns resolve type: " + httpDnsResult.getResolveType());
                    // 优先使用ipv6结果，对于ipv6结果，需要在ip前后增加[]字符
                    // 若不存在ipv6结果，则使用ipv4结果
                    ArrayList<String> ipv6List = httpDnsResult.getIpv6List();
                    ArrayList<String> ipv4List = httpDnsResult.getIpv4List();
                    String ip = null;
                    if (ipv6List != null && !ipv6List.isEmpty()) {
                        ip = "[" + ipv6List.get(0) + "]";
                    } else if (ipv4List != null && !ipv4List.isEmpty()) {
                        ip = ipv4List.get(0);
                    } else {
                        Log.v(TAG, "Get empty iplist from httpdns, use origin url");
                    }
                    if (ip != null)  {
                        // http dns获取解析结果成功，替换url
                        requestUrl = requestUrl.replaceFirst(host, ip);
                        Log.v(TAG, "Use httpdns ip(" + ip
                                + ") for host(" + host + ") requestUrl " + requestUrl);
                        final String finalIp = ip;
                        final String finalHost = host;
                        responseText.post(new Runnable() {
                            @Override
                            public void run() {
                                responseText.append("Get ip:" + finalIp + " for host:"
                                        + finalHost + " from " + httpDnsResult.getResolveType().toString()
                                        + " successfully!\n");
                            }
                        });
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                // 发起请求，打印http status code
                new AsyncHttpRequest().execute(requestUrl, host);
            }
        });

        // 异步接口测试HttpDns服务解析结果，用户可指定https和http类型域名验证解析的IP地址可用
        urlConnAsync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 设置原始url，获取host
                final String requestUrl = urlText.getText().toString();
                final String host;
                try {
                    URL url = new URL(requestUrl);
                    host = url.getHost();
                    if (host == null || host.isEmpty()) {
                        Log.v(TAG, "Err: get nil host from originUrlStr " + requestUrl);
                        return;
                    }
                    // 读取http dns异步解析结果，回调函数参数httpDnsResult存储域名解析结果
                    httpDns.asyncResolve(host, new BDHttpDns.CompletionHandler() {
                        @Override
                        public void completionHandler(final BDHttpDnsResult httpDnsResult) {
                            Log.v(TAG, "HttpDns resolve type: " + httpDnsResult.getResolveType());
                            // 优先使用ipv6结果
                            // 若不存在ipv6结果，则使用ipv4结果
                            ArrayList<String> ipv6List = httpDnsResult.getIpv6List();
                            ArrayList<String> ipv4List = httpDnsResult.getIpv4List();
                            String ip = null;
                            if (ipv6List != null && !ipv6List.isEmpty()) {
                                ip = "[" + ipv6List.get(0) + "]";
                            } else if (ipv4List != null && !ipv4List.isEmpty()) {
                                ip = ipv4List.get(0);
                            } else {
                                Log.v(TAG, "Get empty ipList from http dns, use origin url");
                            }

                            if (ip != null) {
                                // httpdns获取解析结果成功，替换url
                                String request = requestUrl.replaceFirst(host, ip);
                                Log.v(TAG, "Use httpdns ip(" + ip
                                        + ") for host(" + host + ") requestUrl " + request);
                                // 发起请求，打印http status code
                                final String finalIp = ip;
                                responseText.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        responseText.append("Get ip:" + finalIp + " for host:"
                                                + host + " from " + httpDnsResult.getResolveType().toString()
                                                + " successfully!\n");
                                    }
                                });

                                new AsyncHttpRequest().execute(request, host);
                            }
                        }
                    });
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (RejectedExecutionException e) {
                    e.printStackTrace();
                }
            }

        });
    }

    private static String getStringFromInputStream(InputStream in) {
        BufferedReader streamReader = null;
        try {
            streamReader = new BufferedReader(
                    new InputStreamReader(in, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        StringBuilder rspData = new StringBuilder();
        String line;
        if (streamReader != null) {
            try {
                while ((line = streamReader.readLine()) != null) {
                    rspData.append(line);
                }
                streamReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.v(TAG, "response body:" + rspData.toString());
        return rspData.toString();
    }

    /**
     * 异步任务发起Https或http的Get请求,不支持https到http的重定向请求，反之亦然
     */
    public static class AsyncHttpRequest extends AsyncTask<String, Void, Void> {
        private String host;
        private int responseCode;

        @Override
        protected Void doInBackground(final String... params) {
            String url = params[0];
            host = params[1];
            HttpURLConnection conn = null;
            InputStream in;
            try {
                Log.v(TAG, "url(" + url + ") hostName(" + host + ")");
                boolean isHttps = url.contains("https://");
                URL mUrl = new URL(url);

                if (isHttps) {
                    final HttpsURLConnection httpsConn = (HttpsURLConnection) mUrl.openConnection();
                    SNISocketFactory sniSocketFactory = new SNISocketFactory(httpsConn);
                    httpsConn.setSSLSocketFactory(sniSocketFactory);
                    httpsConn.setInstanceFollowRedirects(false);
                    httpsConn.setHostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            String host = httpsConn.getRequestProperty("Host");
                            if (null == host) {
                                host = httpsConn.getURL().getHost();
                            }
                            return HttpsURLConnection.getDefaultHostnameVerifier()
                                    .verify(host, session);
                        }
                    });
                    conn = httpsConn;
                } else {
                    conn = (HttpURLConnection) mUrl.openConnection();
                }
                conn.setRequestProperty("Host", host);
                conn.setRequestMethod("GET");
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(10000);
                conn.setRequestProperty("connection", "Keep-Alive");
                conn.connect();
                responseCode = conn.getResponseCode();
                Log.v(TAG, "Response for url(" + url + ") httpcode("
                                                            + responseCode + ")");
                if (responseCode == 200) {
                    in = conn.getInputStream();
                    if (in != null) {
                        getStringFromInputStream(in);
                    }
                } else if (responseCode == 302 || responseCode == 301) {
                    String location = conn.getHeaderField("Location");
                    Log.v(TAG, "Request redirect to url:" + location);
                } else {
                    in = conn.getErrorStream();
                    if (in != null) {
                        getStringFromInputStream(in);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            responseText.post(new Runnable() {
                @Override
                public void run() {
                    responseText.append("Get response from " + host
                            + "\nPlease check response detail from BDHttpDns log\n");
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
