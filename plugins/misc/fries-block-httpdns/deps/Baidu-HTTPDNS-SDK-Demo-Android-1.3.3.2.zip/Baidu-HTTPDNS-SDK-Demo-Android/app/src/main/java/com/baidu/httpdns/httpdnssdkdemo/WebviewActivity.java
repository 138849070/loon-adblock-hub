package com.baidu.httpdns.httpdnssdkdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.baidu.bdhttpdns.BDHttpDns;
import com.baidu.bdhttpdns.BDHttpDnsResult;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

/**
 * Created by liuxiaoli on 2019/3/12.
 */

public class WebviewActivity extends Activity implements View.OnClickListener {
    private WebView webView;
    private static final String TAG = "BDHttpDnsSdkDemo";
    private BDHttpDns httpDns;
    private Button resolve;
    private EditText urlText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.demo_activity_webview);

        // 初始化httpdns
        httpDns = BDHttpDns.getService(getApplicationContext());
        resolve = (Button) findViewById(R.id.resolve);

        urlText = (EditText) findViewById(R.id.url);

        resolve.setOnClickListener(this);

        webView = (WebView) this.findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient() {
            @SuppressLint("NewApi")
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme().trim();
                String method = request.getMethod();
                Map<String, String> headerFields = request.getRequestHeaders();
                String url = request.getUrl().toString();
                Log.v(TAG, "url:" + url);
                // 拦截方案只能正常处理GET请求，对于POST请求的Body数据，WebResourceRequest接口不支持
                if ((scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))
                        && method.equalsIgnoreCase("get")) {
                    try {
                        URLConnection connection = recursiveRequest(url, headerFields, null);

                        if (connection == null) {
                            Log.e(TAG, "url:" + url + ", connection is null");
                            return super.shouldInterceptRequest(view, request);
                        }
                        String contentType = connection.getContentType();
                        String mime = getMime(contentType);
                        String charset = getCharset(contentType);
                        HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
                        int statusCode = httpURLConnection.getResponseCode();
                        String response = httpURLConnection.getResponseMessage();
                        Map<String, List<String>> headers = httpURLConnection.getHeaderFields();
                        Set<String> headerKeySet = headers.keySet();
                        Log.v(TAG, "url:" + url + ", mime:" + mime + ", charset:" + charset);
                        if (TextUtils.isEmpty(mime)) {
                            // 如果mime为空，则不拦截
                            Log.e(TAG, "url:" + url + ", No MIME, will stop  Intercept! ");
                            return super.shouldInterceptRequest(view, request);
                        } else {
                            // 二进制资源可以不需要编码信息，其他资源需要编码信息
                            if (!TextUtils.isEmpty(charset) || (isBinaryRes(mime))) {
                                WebResourceResponse resourceResponse =
                                        new WebResourceResponse(mime, charset, httpURLConnection.getInputStream());
                                resourceResponse.setStatusCodeAndReasonPhrase(statusCode, response);
                                Map<String, String> responseHeader = new HashMap<String, String>();
                                for (String key : headerKeySet) {
                                    responseHeader.put(key, httpURLConnection.getHeaderField(key));
                                }
                                resourceResponse.setResponseHeaders(responseHeader);
                                return resourceResponse;
                            } else {
                                Log.e(TAG, "url:" + url + ", Non binary resource for " + mime
                                        + ", will stop Intercept!");
                                return super.shouldInterceptRequest(view, request);
                            }
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                // API < 21 只能拦截URL参数
                return super.shouldInterceptRequest(view, url);
            }
        });
    }


    /**
     * 从contentType中获取MIME类型
     * @param contentType
     * @return
     */
    private String getMime(String contentType) {
        if (contentType == null) {
            return null;
        }
        return contentType.split(";")[0];
    }

    /**
     * 从contentType中获取编码信息
     * @param contentType
     * @return
     */
    private String getCharset(String contentType) {
        if (contentType == null) {
            return null;
        }

        String[] fields = contentType.split(";");
        if (fields.length <= 1) {
            return null;
        }

        String charset = fields[1];
        if (!charset.contains("=")) {
            return null;
        }
        charset = charset.substring(charset.indexOf("=") + 1);
        return charset;
    }

    /**
     * 判断是否是二进制资源
     * @param mime
     * @return
     */
    private boolean isBinaryRes(String mime) {
        if (mime.startsWith("image")
                || mime.startsWith("audio")
                || mime.startsWith("video")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * header中是否含有cookie
     * @param headers
     */
    private boolean containCookie(Map<String, String> headers) {
        for (Map.Entry<String, String> headerField : headers.entrySet()) {
            if (headerField.getKey().contains("Cookie")) {
                return true;
            }
        }
        return false;
    }

    public URLConnection recursiveRequest(String path, final Map<String, String> headers, String reffer) {
        try {
            final String host = new URL(path).getHost();

            // dns同步阻塞解析结果
            BDHttpDnsResult httpDnsResult = httpDns.syncResolve(host, false);
            Log.v(TAG, "HttpDns resolve type: " + httpDnsResult.getResolveType());
            // 优先使用ipv6结果，对于ipv6结果，需要在ip前后增加[]字符
            // 若不存在ipv6结果，则使用ipv4结果
            ArrayList<String> ipv6List = httpDnsResult.getIpv6List();
            ArrayList<String> ipv4List = httpDnsResult.getIpv4List();
            String ip = null;
            Log.v(TAG, "ipv6List:" + ipv6List + "ipv4List:" + ipv4List);
            if (ipv6List != null && !ipv6List.isEmpty()) {
                ip = "[" + ipv6List.get(0) + "]";
            } else if (ipv4List != null && !ipv4List.isEmpty()) {
                ip = ipv4List.get(0);
            } else {
                Log.v(TAG, "Get empty iplist from httpdns, use origin url");
            }

            if (ip != null) {
                // http dns解析成功，替换url
                String requestUrl = path.replace(host, ip);
                Log.v(TAG, "Use http dns ip(" + ip
                        + ") for host(" + host + ") requestUrl " + requestUrl);
                HttpURLConnection conn = null;
                conn = (HttpsURLConnection) new URL(requestUrl).openConnection();
                if (headers != null) {
                    for (Map.Entry<String, String> field : headers.entrySet()) {
                        conn.setRequestProperty(field.getKey(), field.getValue());
                    }
                }
                // 设置HTTP请求头Host域
                conn.setRequestProperty("Host", host);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("connection", "Keep-Alive");
                boolean isHttps = requestUrl.contains("https://");
                if (isHttps) {
                    final HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                    SNISocketFactory sniSocketFactory = new SNISocketFactory((HttpsURLConnection) conn);
                    // sni场景，创建SSLScocket
                    httpsConn.setSSLSocketFactory(sniSocketFactory);
                    // https场景，证书校验
                    httpsConn.setHostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            String host = httpsConn.getRequestProperty("Host");
                            if (null == host) {
                                host = httpsConn.getURL().getHost();
                            }
                            return HttpsURLConnection.getDefaultHostnameVerifier()
                                    .verify(host, session);
                        }
                    });
                }
                int responseCode = conn.getResponseCode();
                Log.v(TAG, "Response for url(" + path + ") httpcode("
                        + responseCode + ")");
                if (responseCode == 200) {
                    return conn;
                } else if (responseCode == 302 || responseCode == 301) {
                    // 如果原有header中含有cookie，则不拦截
                    if (containCookie(headers)) {
                        return null;
                    }

                    String location = conn.getHeaderField("Location");
                    if (location == null) {
                        location = conn.getHeaderField("location");
                    }

                    if (location != null) {
                        Log.d(TAG, "Request redirect to url:" + location);
                        if (!(location.startsWith("http://") || location
                                .startsWith("https://"))) {
                            // 某些时候会省略host，只返回后面的path，所以需要补全url
                            location = new URL(path).getProtocol() + "://"
                                    + new URL(path).getHost() + location;
                        }
                        Log.d(TAG, "code:" + responseCode + "; location:" + location + "; path" + path);
                        // TODO：某些场景下follow 重定向会有风险，待解决，by liuxiaoli
                        return recursiveRequest(location, headers, path);
                    } else {
                        // 无法获取location信息，让浏览器获取
                        return null;
                    }
                }
            } else {
                return null;
            }
        } catch (MalformedURLException e) {
            Log.w(TAG, "recursiveRequest MalformedURLException");
        } catch (IOException e) {
            Log.w(TAG, "recursiveRequest IOException");
        } catch (Exception e) {
            Log.w(TAG, "unknow exception");
        }
        return null;
    }

    private static String getStringFromInputStream(InputStream in) {
        BufferedReader streamReader = null;
        try {
            streamReader = new BufferedReader(
                    new InputStreamReader(in, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        StringBuilder rspData = new StringBuilder();
        String line;
        if (streamReader != null) {
            try {
                while ((line = streamReader.readLine()) != null) {
                    rspData.append(line);
                }
                streamReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Log.v(TAG, "response body:" + rspData.toString());
        return rspData.toString();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.resolve:
                String requestUrl = urlText.getText().toString();
                webView.loadUrl(requestUrl);
                break;
            default:
                break;
        }
    }
}

