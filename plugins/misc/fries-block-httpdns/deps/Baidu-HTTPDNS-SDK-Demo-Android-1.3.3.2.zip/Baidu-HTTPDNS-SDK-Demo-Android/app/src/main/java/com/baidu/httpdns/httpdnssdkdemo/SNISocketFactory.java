package com.baidu.httpdns.httpdnssdkdemo;

import android.net.SSLCertificateSocketFactory;
import android.os.Build;
import android.util.Log;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Created by liuxiaoli on 2018/9/27.
 */

class SNISocketFactory extends SSLSocketFactory {
    private final String TAG = SNISocketFactory.class.getSimpleName();
    HostnameVerifier hostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier();
    private HttpsURLConnection conn;

    public SNISocketFactory(HttpsURLConnection conn) {
        this.conn = conn;
    }

    @Override
    public Socket createSocket() throws IOException {
        return null;
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
        return null;
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort)
            throws IOException, UnknownHostException {
        return null;
    }

    @Override
    public Socket createSocket(InetAddress host, int port) throws IOException {
        return null;
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort)
            throws IOException {
        return null;
    }

    @Override
    public Socket createSocket(Socket plainSocket, String host, int port, boolean autoClose)
            throws IOException {
        String hostName = this.conn.getRequestProperty("Host");
        if (hostName == null) {
            hostName = host;
        }
        Log.d(TAG, "SNI hostname is : " + hostName);
        InetAddress inetAddress = plainSocket.getInetAddress();
        if (autoClose) {
            plainSocket.close();
        }
        // 创建 SSLSocket
        SSLCertificateSocketFactory sslSocketFactory =
                (SSLCertificateSocketFactory) SSLCertificateSocketFactory.getDefault(0);
        SSLSocket sslSocket = (SSLSocket) sslSocketFactory.createSocket(inetAddress, port);
        sslSocket.setEnabledProtocols(sslSocket.getSupportedProtocols());
        // 配置SNI
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Log.d(TAG, "Setting SNI on sdk " + Build.VERSION.SDK_INT);
            sslSocketFactory.setHostname(sslSocket, hostName);
        } else {
            Log.d(TAG, "Setting SNI  with reflection on sdk" + Build.VERSION.SDK_INT);
            try {
                java.lang.reflect.Method setHostnameMethod =
                        sslSocket.getClass().getMethod("setHostname", String.class);
                setHostnameMethod.invoke(sslSocket, hostName);

            } catch (Exception e) {
                Log.w(TAG, " SNI Setting failed", e);
            }
        }

        // 主机名验证
        SSLSession session = sslSocket.getSession();
        if (!hostnameVerifier.verify(hostName, session)) {
            throw new SSLPeerUnverifiedException("Verify hostname(" + hostName + ") failed.");
        }
        Log.d(TAG, "Set SNI success.");
        return sslSocket;
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return new String[0];
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return new String[0];
    }
}
